<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Portfolio - Leo Hanney</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css"
        crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css"
        crossorigin="anonymous">
    <link rel="stylesheet" href="https://leohanney.com/css/styles.css">
</head>

<nav class="navbar navbar-expand-lg navbar-dark" style="padding-left: 20px; padding-right: 20px;">
    <a class="navbar-brand" href="https://leohanney.com" style="color: white;">Leo Hanney</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="https://leohanney.com/portfolio" style="color: white;">Portfolio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://leohanney.com/#about" style="color: white;">About</a>
            </li>
        </ul>
    </div>
</nav>


<body>
<div id="page-content">
    <section id="portfolio" class="py-5">
        <div class="container text-center mt-4" style="margin-bottom: 10px;">
            <a href="https://leohanney.com/portfolio" class="btn btn-primary" style="background-color: #343a40; border-color: #343a40;">View More Collections</a>
        </div>
        <div class="container">
            <div id="carouselCollection1" class="carousel slide carousel-dark" data-bs-ride="carousel">
                <div class="carousel-inner" id="carouselInner1"></div>
                <a class="carousel-control-prev" href="#carouselCollection1" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselCollection1" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true" style="color: black;"></span>
                    <span class="visually-hidden">Next</span>
                </a>
            </div>
    </section>

    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2023 Leo Hanney. All rights reserved.</p>
    </footer>

    <div id="larger-image-view">
        <div class="close-button" id="close-button" style="color: red; font-size: 24px; padding: 10px 20px;">&times;</div>
        <div id="carousel-container">
            <!-- Add the carousel navigation buttons here -->
            <a class="carousel-control-prev" href="#" role="button" id="prev-button">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#" role="button" id="next-button">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a>
            <img id="larger-image" src="" alt="Larger Image">
        </div>
    </div>
</div>
    <style>
        /* Override Bootstrap's default carousel button color */
        .carousel-control-prev, .carousel-control-next {
            color: rgba(0, 0, 0); /* Change this color as needed */
        }

        .carousel-inner .carousel-item img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Style for larger image view */
        #larger-image-view {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        text-align: center;
        z-index: 999;
        opacity: 0; /* Start with zero opacity */
        transition: opacity 0.3s ease; /* Add a transition for smooth opacity change */
        }
        
        #larger-image {
        max-width: 80%;
        max-height: 80%;
        margin: auto;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        opacity: 1; /* Update opacity to 1 to make the image fully visible */
        transition: opacity 0.3s ease; /* Add a transition for smooth opacity change */
        }
        
        /* Show the larger image view when it's visible */
        #larger-image-view.active {
        display: block;
        opacity: 1; /* Update opacity to 1 to make the background fully visible */
        }
        
        #larger-image.active {
        opacity: 1; /* Update opacity to 1 to make the image fully visible */

        #close-button {
        font-size: 24px; /* Increase the font size to make the "X" larger */
        padding: 10px 20px; /* Increase padding for better clickability */
        cursor: pointer;
        position: absolute;
        top: 10px;
        right: 10px;
        color: #fff;
        }
    </style>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js" crossorigin="anonymous">
    </script>

    <script>
        const collections = [
            {
                name: 'Collection 1',
                images: [
                    'https://leohanney.com/images/mendipski/image1.webp',
                    'https://leohanney.com/images/mendipski/image2.webp',
                    'https://leohanney.com/images/mendipski/image1.webp',
                    'https://leohanney.com/images/mendipski/image4.webp',
                    'https://leohanney.com/images/mendipski/image5.webp',
                    'https://leohanney.com/images/mendipski/image6.webp',
                    'https://leohanney.com/images/mendipski/image7.webp',
                    'https://leohanney.com/images/mendipski/image8.webp',
                    'https://leohanney.com/images/mendipski/image9.webp',
                    'https://leohanney.com/images/mendipski/image10.webp'
                ]
            }
        ];

        collections.forEach((collection, index) => {
        const carouselInnerId = `carouselInner${index + 1}`;
        const carouselId = `carouselCollection${index + 1}`;
        
        // Create carousel slides
        collection.images.forEach((image, imageIndex) => {
        const carouselSlide = document.createElement('div');
        carouselSlide.classList.add('carousel-item');
        if (imageIndex === 0) {
        carouselSlide.classList.add('active');
        }
        
        const img = document.createElement('img');
        img.src = image;
        img.className = 'd-block w-50 clickable-image'; // Smaller image size
        
        carouselSlide.appendChild(img);
        
        document.getElementById(carouselInnerId).appendChild(carouselSlide);
        });
        
        // JavaScript to handle clickable images
        document.addEventListener("DOMContentLoaded", function () {
        const clickableImages = document.querySelectorAll(".clickable-image");
        const largerImageView = document.getElementById("larger-image-view");
        const largerImage = document.getElementById("larger-image");
        const closeButton = document.getElementById("close-button");
        const prevButton = document.getElementById("prev-button");
        const nextButton = document.getElementById("next-button");
        
        let currentIndex = 0; // Track the current image index
        
        // Function to show the larger image view with a specific image
        function showLargerImage(index) {
        const imageUrl = clickableImages[index].getAttribute("src");
        largerImage.setAttribute("src", imageUrl);
        largerImageView.classList.add("active");
        }
        
        clickableImages.forEach((image, index) => {
        image.addEventListener("click", (e) => {
        e.preventDefault(); // Prevent the default link behavior
        currentIndex = index; // Update the current index
        showLargerImage(currentIndex);
        });
        });
        
        closeButton.addEventListener("click", () => {
        largerImageView.classList.remove("active");
        });
        
        prevButton.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + clickableImages.length) % clickableImages.length;
        showLargerImage(currentIndex);
        });
        
        nextButton.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % clickableImages.length;
        showLargerImage(currentIndex);
        });
        });

        
        // Initialize Carousel
        new bootstrap.Carousel(document.getElementById(carouselId), {
            interval: 5000
        });
        });
    </script>
</body>

</html>